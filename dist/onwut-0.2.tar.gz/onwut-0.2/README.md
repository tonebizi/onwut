# onwut

onwut is a Python library for scraping and processing PDF reports from the METI website.

## Installation

You can install this library using pip:

