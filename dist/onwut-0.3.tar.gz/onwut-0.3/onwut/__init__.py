# onwut/__init__.py

from .core import main, parse_dates
